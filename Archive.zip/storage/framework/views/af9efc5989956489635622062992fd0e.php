<!-- resources/views/welcome.blade.php -->
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
   <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
   <title>GreenTek</title>
</head>

<body class="bg-gray-50 dark:bg-gray-900">

   <div class="min-h-screen antialiased bg-gray-50 dark:bg-gray-900 ">
      <div class="fixed top-0 left-0 z-40 w-64 h-16 flex items-center justify-center ">
         <a href="https://flowbite.com" class="flex items-center space-x-3">
            <img src="<?php echo e(asset('images/logo-mektan.png')); ?>" class="h-8" alt="Flowbite Logo" />
            <span class="text-base font-semibold text-gray-900 dark:text-white">Balai Mekanisasi Pertanian</span>
         </a>
      </div>

      <!-- Sidebar -->
      <?php if (isset($component)) { $__componentOriginald31f0a1d6e85408eecaaa9471b609820 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald31f0a1d6e85408eecaaa9471b609820 = $attributes; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $attributes = $__attributesOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__attributesOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald31f0a1d6e85408eecaaa9471b609820)): ?>
<?php $component = $__componentOriginald31f0a1d6e85408eecaaa9471b609820; ?>
<?php unset($__componentOriginald31f0a1d6e85408eecaaa9471b609820); ?>
<?php endif; ?>
      <!-- End Sidebar -->

      <main class="p-4 md:ml-64 h-auto pt-20">
         <div class="rounded-2xl shadow-sm h-auto bg-white dark:bg-gray-800 p-6">
            <?php echo e($slot); ?>

         </div>
   </div>
   </main>
   </div>
</body>

</html>
<?php /**PATH /Users/wastu/Documents/Code/mektan-app/resources/views/components/layout.blade.php ENDPATH**/ ?>