<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <div class="p-6">
      <h1 class="text-2xl font-bold text-green-600 mb-6">Dashboard Aplikasi</h1>

      
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
         <div class="bg-white p-6 rounded-lg shadow border-l-4 border-green-600">
            <p class="text-sm text-gray-500 mb-1">Total Alat dan Mesin Pertanian</p>
            <p class="text-3xl font-bold text-gray-800"><?php echo e($totalAlsintan); ?></p>
         </div>
         <div class="bg-white p-6 rounded-lg shadow border-l-4 border-green-600">
            <p class="text-sm text-gray-500 mb-1">Mesin yang sedang berjalan</p>
            <p class="text-3xl font-bold text-gray-800"><?php echo e($totalAlsintan); ?></p>
         </div>
      </div>


      
      <div class="bg-white p-6 rounded-lg shadow">
         <h2 class="text-lg font-semibold mb-4 text-gray-700">Jumlah Alat dan Mesin Pertanian per Kategori</h2>
         <canvas id="alsintanChart" width="400" height="200"></canvas>
      </div>
   </div>

   
   <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
   <script>
      const ctx = document.getElementById('alsintanChart').getContext('2d');
      const alsintanChart = new Chart(ctx, {
         type: 'bar',
         data: {
            labels: <?php echo json_encode($labels, 15, 512) ?>,
            datasets: [{
               label: 'Jumlah Alsintan',
               data: <?php echo json_encode($data, 15, 512) ?>,
               backgroundColor: 'rgba(34, 197, 94, 0.5)', // Tailwind green
               borderColor: 'rgba(34, 197, 94, 1)',
               borderWidth: 1
            }]
         },
         options: {
            responsive: true,
            scales: {
               y: {
                  beginAtZero: true,
                  ticks: {
                     precision: 0
                  }
               }
            }
         }
      });
   </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php /**PATH /Users/wastu/Documents/Code/mektan-app/resources/views/dashboard/index.blade.php ENDPATH**/ ?>