<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <div class="bg-white dark:bg-gray-800 relative sm:rounded-lg overflow-hidden">
      <div class="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0 md:space-x-4 p-4">
         <div class="w-full flex items-center justify-between mb-4">
            <h1 class="text-2xl font-bold text-green-700 dark:text-gray-200">
               Data Alat mesin dan pertanian
            </h1>
            <a href="<?php echo e(route('create_alsintan')); ?>"
               class="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg shadow-md transition duration-300">
               Tambah Data
            </a>
         </div>
      </div>
      <div class="overflow-x-auto">
         <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
               <tr>
                  <th scope="col" class="px-4 py-2">Nama</th>
                  <th scope="col" class="px-4 py-2">Kategori</th>
                  <th scope="col" class="px-4 py-2">Merk</th>
                  <th scope="col" class="px-4 py-2">Stock</th>
                  <th scope="col" class="px-4 py-2">Aksi</th> <!-- Kolom baru untuk tombol -->
               </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $alsintans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                     <td class="px-4 py-2 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                        <?php echo e($item->name); ?>

                     </td>
                     <td class="px-4 py-2">
                        <?php echo e($item->category->name ?? '-'); ?>

                     </td>
                     <td class="px-4 py-2">
                        <?php echo e($item->merk->name ?? '-'); ?>

                     </td>
                     <td class="px-4 py-2">
                        <?php echo e($item->stock); ?>

                     </td>
                     <td class="px-4 py-2">
                        <a href="<?php echo e(route('alsintan.show', $item->id)); ?>"
                           class="inline-block px-3 py-1 text-sm font-semibold text-white bg-green-600 rounded hover:bg-green-700">
                           View
                        </a>
                     </td>
                  </tr>
                  </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         </table>
      </div>
      <nav>

         
         <div>
            <?php echo e($alsintans->links()); ?>

         </div>
   </div>
   </nav>
   </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php /**PATH /Users/wastu/Documents/Code/mektan-app/resources/views/asset_management/data_alsintan/index_alsintan.blade.php ENDPATH**/ ?>