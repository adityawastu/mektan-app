<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <div class="flex flex-wrap md:flex-nowrap items-center justify-between md:gap-x-4">
      <div class="w-full sm:w-1/2 md:w-1/4 mb-4 md:mb-0">
         <img src="<?php echo e(asset('images/beranda.png')); ?>" alt="Ilustrasi Mekanisasi" class="w-full h-auto rounded-lg" />
      </div>
      <div class="w-full sm:w-1/2 md:w-3/4 ">
         <h2 class="text-2xl font-bold mb-2 text-green-700 dark:text-gray-200">Sistem Mekanisasi Pertanian</h2>
         <p class="text-base text-black dark:text-gray-200">
            Selamat datang di Sistem Mekanisasi Pertanian, sebuah platform inovatif yang dirancang untuk
            mendukung transformasi pertanian menuju era modern yang efisien dan berbasis teknologi.
            Melalui integrasi data dan pemantauan alat secara real-time, kami membantu petani dan pelaku
            sektor pertanian mengelola peralatan dengan lebih cerdas, meningkatkan produktivitas lahan,
            serta membuat keputusan yang tepat berbasis analisis. Dengan dukungan teknologi seperti IoT
            dan dashboard interaktif, sistem ini hadir sebagai solusi praktis dalam mewujudkan pertanian
            presisi dan berkelanjutan.
         </p>
      </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php /**PATH /Users/wastu/Documents/Code/mektan-app/resources/views/beranda/index.blade.php ENDPATH**/ ?>