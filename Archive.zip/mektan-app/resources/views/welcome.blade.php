<x-layout>
   <div class="flex flex-wrap md:flex-nowrap items-center justify-between md:gap-x-4">
      <div class="w-full sm:w-1/2 md:w-1/4 mb-4 md:mb-0">
         <img src="{{ asset('images/beranda.png') }}" alt="Ilustrasi Mekanisasi" class="w-full h-auto rounded-lg" />
      </div>
 
      <div class="bg-red-500 text-white p-4">Hello World</div>
   </div>
</x-layout>
